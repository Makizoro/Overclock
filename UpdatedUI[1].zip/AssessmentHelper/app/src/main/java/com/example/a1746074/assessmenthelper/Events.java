package com.example.a1746074.assessmenthelper;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by vmuser on 2020/02/28.
 */

public class Events extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_display);

        String Event=getIntent().getStringExtra("Events");
    }
}
