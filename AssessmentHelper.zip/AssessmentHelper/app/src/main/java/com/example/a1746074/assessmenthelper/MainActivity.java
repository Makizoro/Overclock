package com.example.a1746074.assessmenthelper;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    EditText mUsername;
    EditText mPassword;
    Button mButtonLog;
    TextView mRegister;
    TextView mTextWrong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mUsername = (EditText) findViewById(R.id.editText);
        mPassword = (EditText) findViewById(R.id.edPass);
        mButtonLog = (Button) findViewById(R.id.btnLog);
        mRegister = (TextView) findViewById(R.id.txtReg);
        mTextWrong = (TextView)findViewById(R.id.txtwrong);
        mRegister.setOnClickListener(new View.OnClickListener(

        ) {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(registerIntent);
            }
        });
        mButtonLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username=mUsername.getText().toString().trim();
                String password=mPassword.getText().toString().trim();
                ContentValues params = new ContentValues();
                params.put("username",username);
                params.put("password",password);
                AsyncHTTPPost asyncHttpPost = new AsyncHTTPPost(
                        "http://lamp.ms.wits.ac.za/~s1746074/login.php",params) {
                    @Override
                    protected void onPostExecute(String output) {
                        processlogin(output);
                    }
                };
                asyncHttpPost.execute();
            }
        });
    }

    public void processlogin(String output) {
        mPassword = (EditText) findViewById(R.id.edPass);
        String username=mPassword.getText().toString().trim();
        if(output.equals("0")){
            Intent TabsIntent = new Intent(MainActivity.this, Tabs.class);
            TabsIntent.putExtra("userS",username);
            startActivity(TabsIntent);
        }else if(output.equals("1")){
            mTextWrong.setVisibility(View.VISIBLE);
            mTextWrong.setText("Could not find you, sorry!");
        }
    }
}
