package com.example.a1746074.assessmenthelper;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class StudentActivity extends AppCompatActivity {

    Button searching;
    Button mBack3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        mBack3 = (Button) findViewById(R.id.btnBack3);
        searching=(Button)findViewById(R.id.btnSearch);
        mBack3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent MainIntent = new Intent(StudentActivity.this,MainActivity.class);
                startActivity(MainIntent);
            }
        });
        searching.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText u = (EditText)findViewById(R.id.txtSearch);
                String assign = u.getText().toString();
                ContentValues params = new ContentValues();
                params.put("assign",assign);
                @SuppressLint("StaticFieldLeak") AsyncHTTPPost asyncHttpPost = new AsyncHTTPPost(
                        "http://lamp.ms.wits.ac.za/~s1746074/assignment.php",params) {
                    @Override
                    protected void onPostExecute(String output) {
                        processSlist(output);
                    }
                };
                asyncHttpPost.execute();
            }
        });
    }
    public void processSlist(String output){
        LinearLayout l = (LinearLayout)findViewById(R.id.list);
        l.removeAllViews();
        try {
            JSONArray ja = new JSONArray(output);
            for (int i=0; i<ja.length(); i++){
                JSONObject jo = (JSONObject)ja.get(i);
                LinearLayout item = (LinearLayout)getLayoutInflater().inflate(R.layout.group_stuff,null);

                TextView assigntxt = (TextView)item.findViewById(R.id.txtgroup);
                assigntxt.setText(jo.getString("ASSIGN_NAME"));
                final String assign=jo.getString("ASSIGN_NAME");
                final String group_n=jo.getString("ASSIGN_CODE");

                l.addView(item);
                item.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //System.out.println(id);
                        final Button crtgrp = (Button) findViewById(R.id.btnCrtGrp);
                        crtgrp.setVisibility(View.VISIBLE);
                        crtgrp.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                //System.out.println(id);
                                final EditText txtcrt = (EditText) findViewById(R.id.edCrtGrp);
                                txtcrt.setVisibility(View.VISIBLE);
                                final Button btncrt = (Button) findViewById(R.id.btnCrt);
                                btncrt.setVisibility(View.VISIBLE);
                                btncrt.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        String crt = txtcrt.getText().toString();
                                        String userS=getIntent().getStringExtra("userS");
                                        ContentValues params = new ContentValues();
                                        params.put("userS",userS);
                                        params.put("crt",crt);
                                        params.put("group_n",group_n);
                                        @SuppressLint("StaticFieldLeak") AsyncHTTPPost asyncHttpPost = new AsyncHTTPPost(
                                                "http://lamp.ms.wits.ac.za/~s1746074/creategroup.php",params) {
                                            @Override
                                            protected void onPostExecute(String output) {
                                                Toast.makeText(StudentActivity.this, "Successfully created group", Toast.LENGTH_LONG).show();
                                            }
                                        };
                                        asyncHttpPost.execute();
                                    }
                                });
                            }
                        });
                        final Button join = (Button) findViewById(R.id.btnJoin);
                        join.setVisibility(View.VISIBLE);
                        join.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                ContentValues params = new ContentValues();
                                params.put("ASSIGN_NAME",assign);
                                @SuppressLint("StaticFieldLeak") AsyncHTTPPost asyncHttpPost = new AsyncHTTPPost(
                                        "http://lamp.ms.wits.ac.za/~s1746074/giveassign.php",params) {
                                    @Override
                                    protected void onPostExecute(String output) {
                                        processGroupID(output);
                                    }
                                };
                                asyncHttpPost.execute();
                            }
                        });
                    }
                });
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void processGroupID(String output) {
        try {
            JSONArray ja = new JSONArray(output);
            for (int i = 0; i < ja.length(); i++) {
                JSONObject jo = (JSONObject) ja.get(i);

                final String group_id = jo.getString("ASSIGN_CODE");

                ContentValues params = new ContentValues();
                params.put("group_id",group_id);
                @SuppressLint("StaticFieldLeak") AsyncHTTPPost asyncHttpPost = new AsyncHTTPPost(
                        "http://lamp.ms.wits.ac.za/~s1746074/givegroupact.php",params) {
                    @Override
                    protected void onPostExecute(String output) {
                        processGroup(output);
                    }
                };
                asyncHttpPost.execute();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void processGroup(String output) {
        LinearLayout l = (LinearLayout) findViewById(R.id.list);
        l.removeAllViews();
        Log.d("output", output);
        try {
            JSONArray ja = new JSONArray(output);
            for (int i = 0; i < ja.length(); i++) {
                JSONObject jo = (JSONObject) ja.get(i);
                LinearLayout item = (LinearLayout) getLayoutInflater().inflate(R.layout.group_stuff, null);


                TextView assigntxt = (TextView) item.findViewById(R.id.txtgroup);
                assigntxt.setText(jo.getString("GROUP_ACTUAL"));
                final String id = jo.getString("GROUP_ACTUAL");

                l.addView(item);
                item.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String userS=getIntent().getStringExtra("userS");
                        ContentValues params = new ContentValues();
                        params.put("userS",userS);
                        params.put("id", id);
                        @SuppressLint("StaticFieldLeak") AsyncHTTPPost AsyncHttpPost = new AsyncHTTPPost(
                                "http://lamp.ms.wits.ac.za/~s1746074/joingroup.php", params) {
                            @Override
                            protected void onPostExecute(String output) {
                                Toast.makeText(StudentActivity.this, "Successfully joined group", Toast.LENGTH_LONG).show();
                            }
                        };
                        AsyncHttpPost.execute();
                        //marked.setVisibility(View.INVISIBLE);
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
