package com.example.a1746074.assessmenthelper;

import android.support.design.widget.TabLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.Toolbar;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v7.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class Tabs extends AppCompatActivity {

    private static final String TAG = "Tabs";

    private SectionsPageAdapter mSectionsPageAdapter;

    private ViewPager mViewPager;

    String o;
    Button search;
    Button create;
    EditText assignname;
    EditText Apass;
    Button mBack2;
    Button mdela;
    Button mcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tabs);

        String userS=getIntent().getStringExtra("userS");
        search = (Button)findViewById(R.id.button1);
        mBack2 = (Button) findViewById(R.id.btnBack2);
        //assignname = (EditText)findViewById(R.id.AssignName);

        mBack2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent MainIntent = new Intent(Tabs.this,MainActivity.class);
                startActivity(MainIntent);
            }
        });

        /*search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText u = (EditText)findViewById(R.id.assign_search);
                String assign = u.getText().toString();
                ContentValues params = new ContentValues();
                params.put("assign",assign);
                @SuppressLint("StaticFieldLeak") AsyncHTTPPost asyncHttpPost = new AsyncHTTPPost(
                        "http://lamp.ms.wits.ac.za/~s1746074/assignment.php",params) {
                    @Override
                    protected void onPostExecute(String output) {
                        processlist(output);
                    }
                };
                asyncHttpPost.execute();
            }
        });*/
        Log.d(TAG, "onCreate: Starting.");

        mSectionsPageAdapter = new SectionsPageAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container1);
        setupViewPager(mViewPager);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tAbS);
        tabLayout.setupWithViewPager(mViewPager);
    }

    private void setupViewPager(ViewPager viewPager) {
        SectionsPageAdapter adapter = new SectionsPageAdapter(getSupportFragmentManager());
        adapter.addFragment(new Tab1Fragment(), "Clubs");
        adapter.addFragment(new Tab2Fragment(), "Societies");
        adapter.addFragment(new Tab3Fragment(), "Interest Groups");
        viewPager.setAdapter(adapter);
    }

    /*public void processlist(String output){
        LinearLayout l = (LinearLayout)findViewById(R.id.container);
        l.removeAllViews();
        try {
            JSONArray ja = new JSONArray(output);
            for (int i=0; i<ja.length(); i++){
                JSONObject jo = (JSONObject)ja.get(i);
                LinearLayout item = (LinearLayout)getLayoutInflater().inflate(R.layout.tab1_fragment,null);

                TextView assigntxt = (TextView)item.findViewById(R.id.txtassign);
                assigntxt.setText(jo.getString("ASSIGN_NAME"));
                final String id = jo.getString("ASSIGN_NAME");

                final String group_id = jo.getString("ASSIGN_CODE");

                l.addView(item);
                item.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mdela = (Button) findViewById(R.id.btndelass);
                        mcon = (Button) findViewById(R.id.btncon);
                        mcon.setVisibility(View.VISIBLE);
                        mdela.setVisibility(View.VISIBLE);
                        mdela.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                ContentValues params = new ContentValues();
                                params.put("id",id);
                                @SuppressLint("StaticFieldLeak") AsyncHTTPPost asyncHttpPost = new AsyncHTTPPost(
                                        "http://lamp.ms.wits.ac.za/~s1746074/deleteassign.php",params) {
                                    @Override
                                    protected void onPostExecute(String output) {
                                        Toast.makeText(Tabs.this, "Successfully deleted assignment", Toast.LENGTH_LONG).show();
                                    }
                                };
                                asyncHttpPost.execute();
                                mdela.setVisibility(View.GONE);
                                mcon.setVisibility(View.GONE);
                            }
                        });
                        mcon.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                ContentValues params = new ContentValues();
                                params.put("group_id",group_id);
                                @SuppressLint("StaticFieldLeak") AsyncHTTPPost asYncHttpPost = new AsyncHTTPPost(
                                        "http://lamp.ms.wits.ac.za/~s1746074/givegroups.php",params) {
                                    @Override
                                    protected void onPostExecute(String output) {
                                        processGlist(output);
                                    }
                                };
                                asYncHttpPost.execute();
                                mdela.setVisibility(View.GONE);
                                mcon.setVisibility(View.GONE);
                            }
                        });
                    }
                });
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void processGlist(String output) {
        LinearLayout l = (LinearLayout) findViewById(R.id.container);
        l.removeAllViews();
        Log.d("output", output);
        try {
            JSONArray ja = new JSONArray(output);
            for (int i = 0; i < ja.length(); i++) {
                JSONObject jo = (JSONObject) ja.get(i);
                LinearLayout item = (LinearLayout) getLayoutInflater().inflate(R.layout.list_item, null);


                TextView assigntxt = (TextView) item.findViewById(R.id.txtassign);
                assigntxt.setText(jo.getString("GROUP_ACTUAL"));
                final String id = jo.getString("GROUP_ACTUAL");

                l.addView(item);
                item.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        LinearLayout item = (LinearLayout) getLayoutInflater().inflate(R.layout.list_item, null);
                        final EditText marked = (EditText) findViewById(R.id.mark);
                        final Button btnm=(Button)findViewById(R.id.btnmark);
                        marked.setVisibility(View.VISIBLE);
                        btnm.setVisibility(View.VISIBLE);
                        btnm.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String mark = marked.getText().toString();
                                ContentValues params = new ContentValues();
                                params.put("id", id);
                                params.put("mark", mark);
                                @SuppressLint("StaticFieldLeak") AsyncHTTPPost AsyncHttpPost = new AsyncHTTPPost(
                                        "http://lamp.ms.wits.ac.za/~s1746074/mark.php", params) {
                                    @Override
                                    protected void onPostExecute(String output) {
                                        Toast.makeText(Tabs.this, "Successfully updated mark", Toast.LENGTH_LONG).show();
                                    }
                                };
                                AsyncHttpPost.execute();
                            }
                        });
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

}
