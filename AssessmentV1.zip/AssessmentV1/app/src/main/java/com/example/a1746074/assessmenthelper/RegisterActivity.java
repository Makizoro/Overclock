package com.example.a1746074.assessmenthelper;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    EditText mUsername;
    EditText mPassword;
    EditText mPassCon;
    Button mBack;
    Button mReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mUsername = (EditText) findViewById(R.id.edUserReg);
        mPassword = (EditText) findViewById(R.id.edPassReg);
        mPassCon = (EditText) findViewById(R.id.edPassConReg);
        mBack = (Button) findViewById(R.id.btnBack1);
        mReg = (Button) findViewById(R.id.btnReg);
        final CheckBox mStud = (CheckBox) findViewById(R.id.chkstud);
        final CheckBox mLec = (CheckBox) findViewById(R.id.chklec);

        mReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = mUsername.getText().toString();
                String password = mPassword.getText().toString();
                String conpass = mPassCon.getText().toString();
                if(mLec.isChecked()) {
                    if (conpass.equals(password)) {
                        ContentValues params = new ContentValues();
                        params.put("username", username);
                        params.put("password", password);
                        params.put("person", "0");
                        AsyncHTTPPost asyncHttpPost = new AsyncHTTPPost("http://lamp.ms.wits.ac.za/~s1746074/assign.php", params) {
                            @Override
                            protected void onPostExecute(String output) {
                                if (output.equals("0")) {
                                    TextView mWrong = (TextView) findViewById(R.id.txtunmatched);
                                    mWrong.setText("Password already exits.");
                                } else {
                                    Toast.makeText(RegisterActivity.this, "Successfully registered as a lecturer.", Toast.LENGTH_LONG).show();
                                }
                            }
                        };
                        asyncHttpPost.execute();
                    } else {
                        TextView mWrong = (TextView) findViewById(R.id.txtunmatched);
                        mWrong.setText("Passwords do not match.");
                    }
                }else if (mStud.isChecked()){
                    if (conpass.equals(password)) {
                        ContentValues params = new ContentValues();
                        params.put("username", username);
                        params.put("password", password);
                        params.put("person", "1");
                        AsyncHTTPPost asyncHttpPost = new AsyncHTTPPost("http://lamp.ms.wits.ac.za/~s1746074/assign.php", params) {
                            @Override
                            protected void onPostExecute(String output) {
                                if (output.equals("0")) {
                                    TextView mWrong = (TextView) findViewById(R.id.txtunmatched);
                                    mWrong.setText("Password already exits.");
                                } else {
                                    Toast.makeText(RegisterActivity.this, "Successfully registered as a student.", Toast.LENGTH_LONG).show();
                                }
                            }
                        };
                        asyncHttpPost.execute();
                    } else {
                        TextView mWrong = (TextView) findViewById(R.id.txtunmatched);
                        mWrong.setText("Passwords do not match.");
                    }
                }else{
                    TextView mWrong = (TextView) findViewById(R.id.txtunmatched);
                    mWrong.setText("Please select Student or Lecturer");
                }
            }
        });
        mBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent MainIntent = new Intent(RegisterActivity.this,MainActivity.class);
                startActivity(MainIntent);
            }
        });
    }
}
