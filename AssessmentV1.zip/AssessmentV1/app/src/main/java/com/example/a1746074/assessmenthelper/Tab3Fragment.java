package com.example.a1746074.assessmenthelper;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Fragment;
import android.content.ContentValues;
import android.os.Build;
import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class Tab3Fragment extends Fragment {
    private static final String TAG = "Tab1Fragment";
    //private static final String ARG_PARAM2 = "param2";
    private Button btnTEST;
    //@Nullable

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.tabs, container, false);

        // TODO: get array of all Interest groups
        String Interest_id = "";
        ContentValues params = new ContentValues();
        params.put("Interest_id",Interest_id);
        @SuppressLint("StaticFieldLeak") AsyncHTTPPost asYncHttpPost = new AsyncHTTPPost(
                "http://lamp.ms.wits.ac.za/~s1746074/giveInterest.php",params) {
            @Override
            protected void onPostExecute(String output) {
                processInterestlist(output);
            }
        };

        return view;
    }

    @TargetApi(Build.VERSION_CODES.O)
    public void processInterestlist(String output) {
        View view =  getLayoutInflater().inflate(R.layout.tabs, null);
        LinearLayout l = (LinearLayout)view.findViewById(R.id.container);
        l.removeAllViews();
        Log.d("output", output);
        try {
            JSONArray ja = new JSONArray(output);
            for (int i = 0; i < ja.length(); i++) {
                JSONObject jo = (JSONObject) ja.get(i);
                LinearLayout item = (LinearLayout) getLayoutInflater().inflate(R.layout.tabs, null);


                // TODO: Set field to Interest_NAME so I can call that field.
                TextView assigntxt = (TextView) item.findViewById(R.id.tabText);
                assigntxt.setText(jo.getString("Interest_NAME"));
                final String id = jo.getString("Interest_NAME");

                l.addView(item);
                item.setOnClickListener(new View.OnClickListener() {
                    @TargetApi(Build.VERSION_CODES.O)
                    @Override
                    public void onClick(View v) {
                        LinearLayout item = (LinearLayout) getLayoutInflater().inflate(R.layout.tabs, null);
                        String Interest_name = item.toString();
                        ContentValues params = new ContentValues();
                        params.put("Interest_name", Interest_name);
                        // TODO: return array of events for that Interest group
                        @SuppressLint("StaticFieldLeak") AsyncHTTPPost AsyncHttpPost = new AsyncHTTPPost(
                                "http://lamp.ms.wits.ac.za/~s1746074/getInterestevents.php", params) {
                            @Override
                            protected void onPostExecute(String output) {
                                processEventlist(output);
                            }
                        };
                        AsyncHttpPost.execute();
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    };

    @TargetApi(Build.VERSION_CODES.O)
    public void processEventlist(String output) {
        View view =  getLayoutInflater().inflate(R.layout.tabs, null);
        LinearLayout l = (LinearLayout) view.findViewById(R.id.container);
        l.removeAllViews();
        Log.d("output", output);
        try {
            JSONArray ja = new JSONArray(output);
            for (int i = 0; i < ja.length(); i++) {
                JSONObject jo = (JSONObject) ja.get(i);
                LinearLayout item = (LinearLayout) getLayoutInflater().inflate(R.layout.tabs, null);


                // TODO: Set field to Society_NAME so I can call that field.
                TextView assigntxt = (TextView) item.findViewById(R.id.tabText);
                assigntxt.setText(jo.getString("EVENT_ID"));
                final String id = jo.getString("EVENT_ID");

                l.addView(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        ;
    }
}
